// ===== ASSISTANTS: separate chat helper for customer, admin and delivery =====

// Names of the three assistants
const AIN = { customer: 'Shopping Assistant', admin: 'Store Analyst', delivery: 'Delivery Helper' };

// Quick-question buttons for each assistant
const AIS = {
  customer: ['Track my order', 'Active coupons', 'Recommend something', 'What is in my cart?'],
  admin: ['Sales summary', 'Low stock items', 'Pending orders', 'Top selling product'],
  delivery: ['My next delivery', 'How many deliveries today?', 'How to update status?'],
};

// True if an order is still active
const act = (o) => !['Delivered', 'Cancelled'].includes(o.status);

// The assistant brain: reads the question and answers from store data (rule-based)
function ai(q) {
  const t = q.toLowerCase(),
    has = (...w) => w.some((x) => t.includes(x)),
    r = me.role,
    num = (t.match(/\d{4}/) || [])[0],
    L = (a) => a.join('<br>');
  const pm = db.products.filter((p) =>
    p.n
      .toLowerCase()
      .split(' ')
      .some((w) => w.length > 3 && t.includes(w)),
  );
  const pinfo = () =>
    L(
      pm
        .slice(0, 4)
        .map(
          (p) =>
            `${p.e} <b>${esc(p.n)}</b> – ${inr(p.p)} · ${p.s > 0 ? p.s + ' in stock' : 'out of stock'}`,
        ),
    );
  if (/^(hi|hello|hey|help)\b/.test(t))
    return 'I can help with: ' + AIS[r].join(', ').toLowerCase() + '.';
  if (r == 'customer') {
    const mo = db.orders.filter((o) => o.uid == me.id);
    if (pm.length && has('price', 'cost', 'much', 'stock', 'have', 'available', 'sell'))
      return pinfo();
    if (has('track', 'where', 'status', 'order', 'deliver')) {
      let l = num ? mo.filter((o) => o.id == num) : mo.filter(act);
      if (!l.length) l = mo.slice(0, 1);
      if (!l.length) return 'You have no orders yet. Browse the Shop and place your first order!';
      return (
        l
          .map((o) =>
            L([
              `<b>Order #${o.id}</b> – ${o.status}`,
              `${o.items.length} item(s) · ${inr(o.total)} · ${o.slot}`,
              o.driver ? '🛵 ' + esc(du(o.driver).name) : 'Waiting for a delivery partner',
            ]),
          )
          .join('<hr>') + '<br><small>Live tracking is in My Orders.</small>'
      );
    }
    if (has('coupon', 'discount', 'offer', 'promo', 'code'))
      return (
        'Active coupons:<br>' +
        (L(
          db.coupons
            .filter((c) => c.on)
            .map((c) => `<b>${esc(c.code)}</b> – ${c.pct}% off above ${inr(c.min)}`),
        ) || 'None right now.')
      );
    if (has('recommend', 'suggest', 'popular', 'what should')) {
      const bc = new Set(
          mo.filter((o) => o.status != 'Cancelled').flatMap((o) => o.items.map((i) => i.c)),
        ),
        rc = db.products.filter((p) => p.s > 0 && (!bc.size || bc.has(p.c))).slice(0, 4);
      return (
        (bc.size ? 'Based on your past orders you may like:<br>' : 'Popular picks:<br>') +
        L(rc.map((p) => `${p.e} ${esc(p.n)} – ${inr(p.p)}`))
      );
    }
    if (has('cart', 'basket')) {
      const k = Object.keys(ui.cart);
      if (!k.length) return 'Your cart is empty.';
      const x = tot();
      return (
        L(k.map((i) => `${pid(i).e} ${esc(pid(i).n)} ×${ui.cart[i]}`)) +
        `<br><b>Total ${inr(x.total)}</b> (discount ${inr(x.disc)}, delivery ${x.fee ? inr(x.fee) : 'free'})`
      );
    }
    if (has('cancel'))
      return 'You can cancel from My Orders while the status is "Placed". After packing it cannot be cancelled.';
    if (has('fee', 'charge', 'free', 'slot', 'time'))
      return 'Delivery is free above ₹500, otherwise ₹40. Slots: ' + SLOTS.join(', ') + '.';
    if (pm.length) return pinfo();
  }
  if (r == 'admin') {
    const ok = db.orders.filter((o) => o.status != 'Cancelled'),
      rev = ok.reduce((a, o) => a + o.total, 0),
      ds = ok.reduce((a, o) => a + o.disc, 0);
    if (has('sale', 'revenue', 'earn', 'income', 'summary'))
      return L([
        `💰 Total sales: <b>${inr(rev)}</b> from ${ok.length} orders`,
        `🏷 Discounts given: ${inr(ds)}`,
        `📈 Average order: ${inr(ok.length ? rev / ok.length : 0)}`,
        `⏳ Pending: ${db.orders.filter((o) => o.status == 'Placed').length} · Cancelled: ${db.orders.length - ok.length}`,
      ]);
    if (has('stock', 'inventory', 'low', 'restock')) {
      const l = db.products.filter((p) => p.s < 10);
      return l.length
        ? 'Low stock:<br>' + L(l.map((p) => `⚠ ${esc(p.n)} – ${p.s} left`))
        : 'All products are well stocked.';
    }
    if (has('pending', 'new order', 'unassigned', 'assign')) {
      const l = db.orders.filter((o) => o.status == 'Placed' || (act(o) && !o.driver));
      return l.length
        ? L(
            l.map(
              (o) =>
                `#${o.id} ${esc(o.cn)} – ${o.status}${o.driver ? '' : ' (no delivery person)'}`,
            ),
          )
        : 'No pending or unassigned orders.';
    }
    if (has('top', 'best', 'popular', 'selling')) {
      const m = {};
      ok.forEach((o) => o.items.forEach((i) => (m[i.n] = (m[i.n] || 0) + i.q)));
      const e = Object.entries(m)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3);
      return e.length
        ? 'Top sellers:<br>' + L(e.map((x) => `${esc(x[0])} – ${x[1]} sold`))
        : 'No sales yet.';
    }
    if (has('coupon', 'discount', 'promo'))
      return L(
        db.coupons.map(
          (c) =>
            `${esc(c.code)} (${c.pct}%) – used ${db.orders.filter((o) => o.code == c.code && o.status != 'Cancelled').length}× · ${c.on ? 'active' : 'off'}`,
        ),
      );
    if (has('customer'))
      return db.users.filter((u) => u.role == 'customer').length + ' registered customers.';
    if (has('deliver', 'staff', 'driver'))
      return L(
        db.users
          .filter((u) => u.role == 'delivery')
          .map(
            (u) =>
              `🛵 ${esc(u.name)} – ${db.orders.filter((o) => o.driver == u.id && act(o)).length} active, ${db.orders.filter((o) => o.driver == u.id && o.status == 'Delivered').length} delivered`,
          ),
      );
  }
  if (r == 'delivery') {
    const l = db.orders.filter((o) => o.driver == me.id),
      a = l.filter(act);
    if (has('update', 'how to', 'how do'))
      return 'Open <b>My Deliveries</b>. Once the store packs an order tap "Pick up – Out for delivery", then "Mark delivered" after handing over the groceries. The customer is notified automatically.';
    if (has('how many', 'count', 'completed', 'done', 'today'))
      return `You have <b>${a.length}</b> active and <b>${l.filter((o) => o.status == 'Delivered').length}</b> completed deliveries.`;
    if (has('next', 'task', 'current', 'pending', 'address', 'where', 'order')) {
      const x = num ? l.find((o) => o.id == num) : a[0];
      if (!x) return 'No active deliveries assigned to you right now.';
      return L([
        `<b>Order #${x.id}</b> – ${x.status}`,
        `👤 ${esc(x.cn)}${x.ph ? ' · 📞 ' + esc(x.ph) : ''}`,
        `📍 ${esc(x.addr)}`,
        `🕒 ${x.slot} · 💵 ${inr(x.total)}`,
      ]);
    }
  }
  return 'Sorry, I did not get that. Try: ' + AIS[r].join(' · ');
}

// Draw the assistant button and chat window
function aiR() {
  const el = $('#ai');
  el.dataset.r = me ? me.role : '';
  if (!me) {
    el.innerHTML = '';
    return;
  }
  const r = me.role,
    m = ui.chat[r];
  el.innerHTML =
    `<button class="aib" onclick="ui.ai=!ui.ai;aiR()" title="${AIN[r]}">${ui.ai ? '✕' : '🤖'}</button>` +
    (ui.ai
      ? `<div class="aip"><div class="aih">🤖 ${AIN[r]}</div><div class="aim" id="aim">${m.length ? m.map((x) => `<div class="m ${x[0]}">${x[1]}</div>`).join('') : `<div class="m b">Hi ${esc(me.name.split(' ')[0])}! I am your ${AIN[r].toLowerCase()}. Pick a question below or type your own.</div>`}</div><div class="aic">${AIS[r].map((s) => `<button class="chip" onclick="aiAsk('${s}')">${s}</button>`).join('')}</div><form onsubmit="aiSend(event)" class="row" style="margin:0;padding:8px"><input id="aiq" placeholder="Type your question…" style="flex:1;min-width:0" autocomplete="off"><button class="b">Send</button></form></div>`
      : '');
  const a = $('#aim');
  if (a) a.scrollTop = a.scrollHeight;
  const i = $('#aiq');
  if (i) i.focus();
}

// Send the typed question
function aiSend(e) {
  e.preventDefault();
  const v = $('#aiq').value.trim();
  if (v) aiAsk(v);
}

// Add question + answer to the chat
function aiAsk(q) {
  ui.chat[me.role].push(['u', esc(q)], ['b', ai(q)]);
  aiR();
}
