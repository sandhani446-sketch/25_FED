// ===== ADMIN: dashboard, orders, inventory, coupons, customers, staff, backup =====

// Change an order status and notify the customer
function setStatus(id, s) {
  const o = db.orders.find((x) => x.id == id);
  if (o.status == s) return;
  if (s == 'Cancelled')
    o.items.forEach((i) => {
      const p = pid(i.id);
      if (p) p.s += i.q;
    });
  o.status = s;
  (o.hist = o.hist || []).push({ s, t: new Date().toISOString() });
  const m = {
    Packed: 'is packed and ready',
    'Out for delivery': 'is out for delivery 🛵',
    Delivered: 'was delivered. Enjoy! 🎉',
    Cancelled: 'was cancelled',
  };
  if (m[s]) note(o.uid, 'Order #' + id + ' ' + m[s]);
  if (o.driver && s == 'Packed') note(o.driver, 'Order #' + id + ' is packed – ready for pickup');
  if (s == 'Delivered') note('r:admin', 'Order #' + id + ' delivered');
  save();
  R();
}

// Assign a delivery person to an order
function assign(id, v) {
  const o = db.orders.find((x) => x.id == id);
  o.driver = v ? +v : null;
  if (v) {
    note(+v, 'New delivery assigned: Order #' + id + ' (' + o.slot + ')');
    note(o.uid, 'Order #' + id + ' will be delivered by ' + du(+v).name);
  }
  save();
  toast('Delivery person assigned');
  R();
}

// Admin dashboard: sales, orders, discounts, low stock
function dash() {
  const ok = db.orders.filter((o) => o.status != 'Cancelled'),
    rev = ok.reduce((a, o) => a + o.total, 0),
    ds = ok.reduce((a, o) => a + o.disc, 0),
    low = db.products.filter((p) => p.s < 10).length;
  const bycat = {};
  ok.forEach((o) => o.items.forEach((i) => (bycat[i.c] = (bycat[i.c] || 0) + i.p * i.q)));
  const mx = Math.max(1, ...Object.values(bycat));
  return `<div class="stats"><div class="stat"><small>Total sales</small><h2>${inr(rev)}</h2></div><div class="stat"><small>Orders</small><h2>${ok.length}</h2></div><div class="stat"><small>Discounts given</small><h2>${inr(ds)}</h2></div><div class="stat"><small>Pending orders</small><h2>${db.orders.filter((o) => o.status == 'Placed').length}</h2></div><div class="stat"><small>Low stock items</small><h2>${low}</h2></div></div>
<div class="card"><h3 style="margin-top:0">Sales by category</h3>${
    Object.keys(bycat)
      .map(
        (c) =>
          `<div class="row"><span style="width:100px">${c}</span><div style="flex:1"><div class="bar" style="width:${(bycat[c] / mx) * 100}%"></div></div><b>${inr(bycat[c])}</b></div>`,
      )
      .join('') || '<p class="mu">No sales yet.</p>'
  }</div>`;
}

// Admin orders table
function aOrders() {
  const dv = db.users.filter((u) => u.role == 'delivery');
  return `<div class="card tw"><table><tr><th>#</th><th>Customer</th><th>Total</th><th>Slot</th><th>Status</th><th>Delivery person</th></tr>${
    db.orders
      .map(
        (
          o,
        ) => `<tr><td>${o.id}</td><td>${esc(o.cn)}<br><small class="mu">${esc(o.addr)}</small></td><td>${inr(o.total)}</td><td>${o.slot}</td>
<td><select onchange="setStatus(${o.id},this.value)">${[...ST, 'Cancelled'].map((s) => `<option ${s == o.status ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
<td><select onchange="assign(${o.id},this.value)"><option value="">Unassigned</option>${dv.map((d) => `<option value="${d.id}" ${o.driver == d.id ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select></td></tr>`,
      )
      .join('') || '<tr><td colspan=6 class="mu">No orders yet.</td></tr>'
  }</table></div>`;
}

// Quick edit of price/stock in the inventory table
function upd(id, k, v) {
  const p = pid(id);
  p[k] = Math.max(0, +v);
  save();
  toast('Updated');
}

// Add a new product or update an existing one
function saveProd(e) {
  e.preventDefault();
  const f = e.target,
    fi = f.img.files[0];
  const fin = (img) => {
    const d = {
      n: f.n.value.trim(),
      e: f.e.value || '🛍️',
      c: f.c.value.trim(),
      brand: f.brand.value.trim(),
      unit: f.unit.value.trim(),
      p: +f.p.value,
      s: +f.s.value,
      desc: f.desc.value.trim(),
    };
    if (img) d.img = img;
    if (ui.ep) Object.assign(pid(ui.ep), d);
    else db.products.push({ id: db.np++, ...d });
    save();
    toast(ui.ep ? 'Product updated' : 'Product added');
    ui.ep = 0;
    R();
  };
  if (!fi) return fin();
  const r = new FileReader();
  r.onload = () => {
    const im = new Image();
    im.onload = () => {
      const c = document.createElement('canvas'),
        k = Math.min(1, 160 / Math.max(im.width, im.height));
      c.width = im.width * k;
      c.height = im.height * k;
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      fin(c.toDataURL('image/jpeg', 0.7));
    };
    im.src = r.result;
  };
  r.readAsDataURL(fi);
}

// Delete a product
function delProd(id) {
  if (confirm('Delete product?')) {
    db.products = db.products.filter((p) => p.id != id);
    delete ui.cart[id];
    save();
    R();
  }
}

// Admin inventory page (form + table)
function aProds() {
  const ep = pid(ui.ep) || {};
  return `<div class="card"><h3 style="margin-top:0">${ep.id ? 'Edit product #' + ep.id : 'Add new product'}</h3><form class="row" onsubmit="saveProd(event)" style="margin:0" id="pf"><input name="n" placeholder="Product name" required value="${esc(ep.n || '')}"><input name="e" placeholder="Emoji" style="width:70px" value="${esc(ep.e || '')}"><input name="c" placeholder="Category" required list="cl" value="${esc(ep.c || '')}"><datalist id="cl">${[...new Set(db.products.map((p) => p.c))].map((c) => `<option>${c}</option>`).join('')}</datalist><input name="brand" placeholder="Brand" value="${esc(ep.brand || '')}"><input name="unit" placeholder="Unit (1 kg, 500 ml)" value="${esc(ep.unit || '')}"><input name="p" type="number" min="1" placeholder="Price ₹" required style="width:100px" value="${ep.p || ''}"><input name="s" type="number" min="0" placeholder="Stock" required style="width:90px" value="${ep.s ?? ''}"><input name="desc" placeholder="Description" style="flex:1;min-width:200px" value="${esc(ep.desc || '')}"><label class="mu">Photo <input type="file" name="img" accept="image/*"></label><button class="b">${ep.id ? 'Update product' : 'Add product'}</button>${ep.id ? '<button type="button" class="b o" onclick="ui.ep=0;R()">Cancel</button>' : ''}</form></div>
<div class="card tw"><table><tr><th>Product</th><th>Category</th><th>Price ₹</th><th>Stock</th><th></th></tr>${db.products.map((p) => `<tr><td>${p.img ? `<img src="${p.img}" width="26" height="26" style="border-radius:6px;vertical-align:middle">` : p.e} ${esc(p.n)}<br><small class="mu">${esc(p.brand || '')} ${esc(p.unit || '')}</small></td><td>${esc(p.c)}</td><td><input type="number" value="${p.p}" style="width:90px" onchange="upd(${p.id},'p',this.value)"></td><td><input type="number" value="${p.s}" style="width:80px" onchange="upd(${p.id},'s',this.value)"></td><td><button class="b o s" onclick="ui.ep=${p.id};R();scrollTo(0,0)">Edit</button> <button class="b d s" onclick="delProd(${p.id})">Delete</button></td></tr>`).join('')}</table></div>`;
}

// Create a coupon
function addCp(e) {
  e.preventDefault();
  const f = e.target,
    c = f.code.value.trim().toUpperCase();
  if (db.coupons.some((x) => x.code == c)) return toast('Code exists');
  db.coupons.push({ code: c, pct: +f.pct.value, min: +f.min.value, on: true });
  save();
  R();
}

// Enable / disable a coupon
function tglCp(c) {
  const x = db.coupons.find((y) => y.code == c);
  x.on = !x.on;
  save();
  R();
}

// Delete a coupon
function delCp(c) {
  db.coupons = db.coupons.filter((y) => y.code != c);
  save();
  R();
}

// Admin discounts page
function aCoupons() {
  return `<div class="card"><form class="row" onsubmit="addCp(event)" style="margin:0"><input name="code" placeholder="CODE" required><input name="pct" type="number" min="1" max="90" placeholder="Discount %" required><input name="min" type="number" min="0" placeholder="Min order ₹" required><button class="b">Create coupon</button></form></div>
<div class="card tw"><table><tr><th>Code</th><th>Discount</th><th>Min order</th><th>Used</th><th>Status</th><th></th></tr>${db.coupons.map((c) => `<tr><td><b>${esc(c.code)}</b></td><td>${c.pct}%</td><td>${inr(c.min)}</td><td>${db.orders.filter((o) => o.code == c.code && o.status != 'Cancelled').length}×</td><td><span class="tag ${c.on ? '' : 'Cancelled'}">${c.on ? 'Active' : 'Off'}</span></td><td><button class="b o s" onclick="tglCp('${c.code}')">${c.on ? 'Disable' : 'Enable'}</button> <button class="b d s" onclick="delCp('${c.code}')">Delete</button></td></tr>`).join('')}</table></div>`;
}

// Admin customers page
function aCust() {
  const cs = db.users.filter((u) => u.role == 'customer');
  return `<div class="card tw"><table><tr><th>Name</th><th>Username</th><th>Phone</th><th>Address</th><th>Orders</th><th>Spent</th><th></th></tr>${cs
    .map((u) => {
      const o = db.orders.filter((x) => x.uid == u.id && x.status != 'Cancelled');
      return `<tr><td>${esc(u.name)}</td><td>${esc(u.user)}</td><td>${esc(u.phone || '-')}</td><td>${esc(u.addr || '-')}</td><td>${o.length}</td><td>${inr(o.reduce((a, x) => a + x.total, 0))}</td><td><button class="b d s" onclick="delUser(${u.id})">Remove</button></td></tr>`;
    })
    .join('')}</table></div>`;
}

// Remove a user
function delUser(id) {
  if (confirm('Remove this user?')) {
    db.users = db.users.filter((u) => u.id != id);
    save();
    R();
  }
}

// Add a delivery person
function addStaff(e) {
  e.preventDefault();
  const f = e.target;
  if (db.users.some((a) => a.user == f.user.value)) return toast('Username taken');
  db.users.push({
    id: db.nu++,
    role: 'delivery',
    name: f.name.value,
    user: f.user.value,
    pass: f.pass.value,
    phone: f.phone.value,
    veh: f.veh.value,
  });
  save();
  R();
}

// Admin delivery staff page
function aStaff() {
  return `<div class="card"><form class="row" onsubmit="addStaff(event)" style="margin:0"><input name="name" placeholder="Name" required><input name="phone" placeholder="Phone" required><input name="veh" placeholder="Vehicle no."><input name="user" placeholder="Username" required><input name="pass" placeholder="Password" required><button class="b">Add delivery person</button></form></div>
<div class="card tw"><table><tr><th>Name</th><th>Phone</th><th>Vehicle</th><th>Username</th><th>Assigned</th><th>Delivered</th><th></th></tr>${db.users
    .filter((u) => u.role == 'delivery')
    .map(
      (u) =>
        `<tr><td>${esc(u.name)}</td><td>${esc(u.phone || '-')}</td><td>${esc(u.veh || '-')}</td><td>${esc(u.user)}</td><td>${db.orders.filter((o) => o.driver == u.id).length}</td><td>${db.orders.filter((o) => o.driver == u.id && o.status == 'Delivered').length}</td><td><button class="b d s" onclick="delUser(${u.id})">Remove</button></td></tr>`,
    )
    .join('')}</table></div>`;
}

// Download all data as a JSON backup
function expo() {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(
    new Blob([JSON.stringify(db, null, 1)], { type: 'application/json' }),
  );
  a.download = 'freshcart-data.json';
  a.click();
}

// Restore data from a JSON backup
function impo(i) {
  const f = i.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      const d = JSON.parse(r.result);
      if (!d.users || !d.products) throw 0;
      db = d;
      db.notes = db.notes || [];
      save();
      me = db.users.find((u) => u.id == me.id) || null;
      toast('Data imported');
      R();
    } catch (x) {
      toast('Invalid backup file');
    }
  };
  r.readAsText(f);
}
