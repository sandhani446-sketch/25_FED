// ===== DELIVERY PERSON: assigned orders and status updates =====

// Delivery person moves an order to its next stage
function nextSt(id) {
  const o = db.orders.find((x) => x.id == id),
    i = ST.indexOf(o.status);
  if (i < 3) setStatus(id, ST[i + 1]);
}

// Delivery person home: assigned orders
function tasks() {
  const l = db.orders.filter((o) => o.driver == me.id),
    act = l.filter((o) => !['Delivered', 'Cancelled'].includes(o.status));
  return `<div class="stats"><div class="stat"><small>Active deliveries</small><h2>${act.length}</h2></div><div class="stat"><small>Completed</small><h2>${l.filter((o) => o.status == 'Delivered').length}</h2></div></div>
${
  l
    .map(
      (
        o,
      ) => `<div class="card"><b>Order #${o.id}</b> · ${esc(o.cn)}${o.ph ? ' · 📞 ' + esc(o.ph) : ''} · ${inr(o.total)}<br><span class="mu">📍 ${esc(o.addr)} · 🕒 ${o.slot}</span>${trk(o)}
${o.status == 'Packed' ? `<button class="b" onclick="nextSt(${o.id})">Pick up – Out for delivery</button>` : o.status == 'Out for delivery' ? `<button class="b" onclick="nextSt(${o.id})">Mark delivered</button>` : o.status == 'Placed' ? '<span class="mu">Waiting for store to pack this order</span>' : ''}</div>`,
    )
    .join('') || '<div class="card">No deliveries assigned yet.</div>'
}`;
}
