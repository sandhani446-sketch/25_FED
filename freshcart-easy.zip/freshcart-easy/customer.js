// ===== CUSTOMER: shop, cart, checkout, order tracking =====

// Add one item to the cart (checks stock)
function add(id) {
  const p = pid(id),
    q = ui.cart[id] || 0;
  if (q >= p.s) return toast('Only ' + p.s + ' in stock');
  ui.cart[id] = q + 1;
  toast(p.n + ' added');
  R();
}

// Change cart quantity by +1 / -1
function chg(id, d) {
  const q = (ui.cart[id] || 0) + d;
  if (q <= 0) delete ui.cart[id];
  else if (q <= pid(id).s) ui.cart[id] = q;
  R();
}

// Calculate subtotal, discount, delivery fee and total
function tot() {
  let sub = 0;
  for (const id in ui.cart) sub += pid(id).p * ui.cart[id];
  const c = ui.cp && db.coupons.find((x) => x.code == ui.cp && x.on);
  const disc = c && sub >= c.min ? Math.round((sub * c.pct) / 100) : 0;
  const fee = sub - disc >= 500 || !sub ? 0 : 40;
  return { sub, disc, fee, total: sub - disc + fee };
}

// Apply a coupon code to the cart
function applyCp() {
  const v = $('#cp').value.trim().toUpperCase(),
    c = db.coupons.find((x) => x.code == v && x.on);
  if (!c) return toast('Invalid coupon');
  if (tot().sub < c.min) return toast('Minimum order ' + inr(c.min));
  ui.cp = v;
  toast(c.pct + '% discount applied');
  R();
}

// Place the order: reduce stock, save order, send notifications
function place() {
  const t = tot(),
    a = $('#addr').value.trim(),
    sl = $('#slot').value;
  if (!t.sub) return;
  if (!a) return toast('Enter delivery address');
  const id = db.nid++,
    items = Object.keys(ui.cart).map((k) => {
      const p = pid(k);
      p.s -= ui.cart[k];
      if (p.s < 10) note('r:admin', 'Low stock: ' + p.n + ' (' + p.s + ' left)');
      return { id: p.id, n: p.n, e: p.e, c: p.c, p: p.p, q: ui.cart[k] };
    });
  me.addr = a;
  db.orders.unshift({
    id,
    uid: me.id,
    cn: me.name,
    ph: me.phone || '',
    items,
    ...t,
    code: t.disc ? ui.cp : '',
    slot: sl,
    addr: a,
    status: 'Placed',
    driver: null,
    date: new Date().toISOString(),
    hist: [{ s: 'Placed', t: new Date().toISOString() }],
  });
  note(me.id, 'Order #' + id + ' placed successfully – total ' + inr(t.total));
  note('r:admin', 'New order #' + id + ' from ' + me.name + ' (' + inr(t.total) + ')');
  save();
  ui.cart = {};
  ui.cp = null;
  toast('Order placed!');
  go('orders');
}

// Customer cancels an order that is still "Placed"
function cancelMine(id) {
  if (confirm('Cancel this order?')) {
    note('r:admin', 'Customer cancelled order #' + id);
    setStatus(id, 'Cancelled');
  }
}

const tagc = (s) => (s == 'Out for delivery' ? 'Out' : s);

// Delivery tracking line with time of each stage
function trk(o) {
  if (o.status == 'Cancelled') return '<span class="tag Cancelled">Cancelled</span>';
  const i = ST.indexOf(o.status),
    h = o.hist || [],
    pc = (i / 3) * 100;
  return `<div class="road"><div class="fill" style="width:${pc}%"></div><span class="rider" style="left:${pc}%">${i == 3 ? '🏠' : '🛵'}</span></div><div class="trk">${ST.map(
    (s, k) => {
      const x = h.find((y) => y.s == s);
      return `<i class="${k <= i ? 'on' : ''}">${s}<br><small>${x ? new Date(x.t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}</small></i>`;
    },
  ).join('')}</div>`;
}

// One product card in the shop
function pcard(p) {
  return `<div class="card prod">${p.img ? `<img src="${p.img}" alt="">` : `<div class="e">${p.e}</div>`}<h4>${esc(p.n)}</h4><small>${esc(p.brand || p.c)}${p.unit ? ' · ' + esc(p.unit) : ''}</small>${p.desc ? `<div class="mu" style="font-size:12px">${esc(p.desc)}</div>` : ''}<small class="mu">${p.s > 0 ? (p.s < 10 ? '⚠ Only ' + p.s + ' left' : p.s + ' in stock') : 'Out of stock'}</small><div class="pr">${inr(p.p)}</div><button class="b s" ${p.s < 1 ? 'disabled' : ''} onclick="add(${p.id})">Add to cart</button></div>`;
}

// Shop page: search, categories, recommendations, products
function shop() {
  const cats = ['All', ...new Set(db.products.map((p) => p.c))],
    q = ui.q.toLowerCase();
  const list = db.products.filter(
    (p) => (ui.cat == 'All' || p.c == ui.cat) && p.n.toLowerCase().includes(q),
  );
  const mine = db.orders.filter((o) => o.uid == me.id && o.status != 'Cancelled'),
    bc = new Set(mine.flatMap((o) => o.items.map((i) => i.c)));
  const rec = (bc.size ? db.products.filter((p) => bc.has(p.c) && p.s > 0) : db.products).slice(
    0,
    4,
  );
  return `<div class="row"><input id="q" placeholder="🔍 Search groceries" value="${esc(ui.q)}" oninput="ui.q=this.value;R(1)" style="flex:1;min-width:200px"></div>
<div class="row">${cats.map((c) => `<button class="chip ${ui.cat == c ? 'on' : ''}" onclick="ui.cat='${c}';R()">${c}</button>`).join('')}</div>
${!q && ui.cat == 'All' ? `<h3>${bc.size ? 'Recommended for you' : 'Popular picks'}</h3><div class="grid">${rec.map(pcard).join('')}</div><h3>All products</h3>` : ''}
<div class="grid">${list.map(pcard).join('') || '<p class="mu">No products found.</p>'}</div>`;
}

// Cart + checkout page
function cart() {
  const ids = Object.keys(ui.cart),
    t = tot();
  if (!ids.length)
    return '<div class="card">Your cart is empty. <a href="#" onclick="go(\'shop\');return false">Start shopping</a></div>';
  const c = ui.cp && db.coupons.find((x) => x.code == ui.cp);
  return `<div class="two"><div class="card tw"><table><tr><th>Item</th><th>Price</th><th>Qty</th><th>Total</th></tr>${ids
    .map((id) => {
      const p = pid(id);
      return `<tr><td>${p.e} ${esc(p.n)}</td><td>${inr(p.p)}</td><td><button class="b s o" onclick="chg(${id},-1)">−</button> ${ui.cart[id]} <button class="b s o" onclick="chg(${id},1)">+</button></td><td>${inr(p.p * ui.cart[id])}</td></tr>`;
    })
    .join('')}</table></div>
<div class="card"><h3 style="margin-top:0">Checkout</h3><div class="row"><input id="cp" placeholder="Coupon code" value="${ui.cp || ''}" style="flex:1;min-width:0"><button class="b o" onclick="applyCp()">Apply</button></div>
<div class="row" style="display:block"><label class="mu">Delivery slot</label><br><select id="slot" style="width:100%">${SLOTS.map((s) => `<option>${s}</option>`).join('')}</select></div>
<textarea id="addr" rows="3" placeholder="Delivery address" style="width:100%;margin-bottom:10px">${esc(me.addr || '')}</textarea>
<p>Subtotal: <b>${inr(t.sub)}</b><br>Discount${c ? ' (' + c.code + ')' : ''}: <b>−${inr(t.disc)}</b><br>Delivery: <b>${t.fee ? inr(t.fee) : 'FREE'}</b><br><span style="font-size:18px">Total: <b>${inr(t.total)}</b></span></p><p class="mu" style="font-size:13px">Free delivery above ₹500.</p>
<button class="b" style="width:100%" onclick="place()">Place order</button></div></div>`;
}

// One order card with tracking
function ordCard(o, role) {
  const d = o.driver && du(o.driver);
  return `<div class="card"><div class="row" style="justify-content:space-between;margin:0"><b>Order #${o.id}</b><span class="mu">${new Date(o.date).toLocaleString()}</span></div>
<div class="mu">${o.items.map((i) => i.e + ' ' + esc(i.n) + ' ×' + i.q).join(', ')}</div><div class="mu" style="font-size:13px">📍 ${esc(o.addr)} · 🕒 ${o.slot}</div>${trk(o)}
<div class="row" style="margin:0;justify-content:space-between"><span>Total <b>${inr(o.total)}</b>${o.code ? ' · coupon ' + o.code : ''}</span>${d ? `<span class="mu">🛵 ${esc(d.name)}${d.phone ? ' · 📞 ' + esc(d.phone) : ''}${d.veh ? ' · ' + esc(d.veh) : ''}</span>` : ''}${role == 'c' && o.status == 'Placed' ? `<button class="b d s" onclick="cancelMine(${o.id})">Cancel</button>` : ''}</div></div>`;
}

// Customer order history page
function myOrders() {
  const l = db.orders.filter((o) => o.uid == me.id);
  return l.length
    ? l.map((o) => ordCard(o, 'c')).join('')
    : '<div class="card">No orders yet.</div>';
}
