// ===== NOTIFICATIONS: bell icon, yellow bar, updates across browser tabs =====

// Add a notification for one user (id) or a whole role ("r:admin")
function note(to, msg) {
  db.notes.unshift({ id: Date.now() + Math.random(), to, msg, t: new Date().toISOString(), r: 0 });
  db.notes = db.notes.slice(0, 200);
}

// Notifications that belong to the logged-in user
const mine = () => db.notes.filter((n) => n.to === me.id || n.to === 'r:' + me.role);

// Turn a time into "5 min ago"
const ago = (t) => {
  const m = Math.round((Date.now() - new Date(t)) / 6e4);
  return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : new Date(t).toLocaleString();
};

// Mark all notifications as read
function readAll() {
  mine().forEach((n) => (n.r = 1));
  save();
  ui.nb = 0;
  R();
}

// Yellow notification bar + notification list
function bar() {
  const l = mine(),
    u = l.filter((n) => !n.r);
  let h = '';
  if (u.length)
    h += `<div class="nbar">🔔 <span>${esc(u[0].msg)} <small>· ${ago(u[0].t)}</small></span><button onclick="readAll()">${u.length > 1 ? 'Mark all read (' + u.length + ')' : 'Dismiss'}</button></div>`;
  if (ui.nb)
    h += `<div class="card"><b>Notifications</b>${
      l
        .slice(0, 15)
        .map(
          (n) => `<div class="ni ${n.r ? '' : 'un'}">${esc(n.msg)}<small>${ago(n.t)}</small></div>`,
        )
        .join('') || '<p class="mu">No notifications yet.</p>'
    }</div>`;
  return h;
}

window.addEventListener('storage', (e) => {
  if (e.key != K || !me) return;
  try {
    db = JSON.parse(e.newValue) || db;
    db.notes = db.notes || [];
  } catch (x) {
    return;
  }
  me = db.users.find((u) => u.id == me.id);
  if (!me) return logout();
  R(1);
  const u = mine().filter((n) => !n.r);
  if (u.length) toast('🔔 ' + u[0].msg);
});
