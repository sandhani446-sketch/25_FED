// ===== DATA & HELPERS: settings, demo data, saving to localStorage, small helper functions =====

// Short for document.querySelector
const $ = (s) => document.querySelector(s),
  esc = (s) =>
    String(s).replace(
      /[&<>"']/g,
      (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c],
    );

// Settings: storage key, order stages, money format
const K = 'freshcart_v1',
  ST = ['Placed', 'Packed', 'Out for delivery', 'Delivered'],
  inr = (n) => '₹' + Number(n).toFixed(0);

// Delivery time slots shown at checkout
const SLOTS = ['Today 6–8 PM', 'Tomorrow 8–10 AM', 'Tomorrow 12–2 PM', 'Tomorrow 6–8 PM'];

// db = ALL app data (users, products, orders, coupons, notifications)
let db = null;

try {
  db = JSON.parse(localStorage.getItem(K));
} catch (e) {}

// Starting demo data: 3 demo users, 16 products, 2 coupons
function seed() {
  const P = [
    ['Tomatoes 1kg', '🍅', 'Vegetables', 40],
    ['Potatoes 1kg', '🥔', 'Vegetables', 35],
    ['Onions 1kg', '🧅', 'Vegetables', 38],
    ['Spinach bunch', '🥬', 'Vegetables', 20],
    ['Bananas 1 doz', '🍌', 'Fruits', 60],
    ['Apples 1kg', '🍎', 'Fruits', 150],
    ['Mangoes 1kg', '🥭', 'Fruits', 120],
    ['Milk 1L', '🥛', 'Dairy', 58],
    ['Paneer 200g', '🧀', 'Dairy', 90],
    ['Eggs 12', '🥚', 'Dairy', 84],
    ['Basmati Rice 5kg', '🍚', 'Staples', 520],
    ['Wheat Flour 5kg', '🌾', 'Staples', 260],
    ['Toor Dal 1kg', '🫘', 'Staples', 165],
    ['Bread loaf', '🍞', 'Bakery', 45],
    ['Biscuits pack', '🍪', 'Snacks', 30],
    ['Orange Juice 1L', '🧃', 'Beverages', 110],
  ];
  return {
    users: [
      { id: 1, role: 'admin', name: 'Store Admin', user: 'admin', pass: 'admin123' },
      { id: 2, role: 'delivery', name: 'Ravi Kumar', user: 'delivery', pass: 'deliver123' },
      { id: 3, role: 'customer', name: 'Demo Customer', user: 'customer', pass: 'cust123' },
    ],
    products: P.map((p, i) => ({ id: i + 1, n: p[0], e: p[1], c: p[2], p: p[3], s: 30 + i * 3 })),
    orders: [],
    coupons: [
      { code: 'FRESH10', pct: 10, min: 200, on: true },
      { code: 'WELCOME20', pct: 20, min: 500, on: true },
    ],
    nid: 1001,
    nu: 4,
    np: 17,
  };
}

if (!db) db = seed();

db.notes = db.notes || [];

// Save all data to the browser (localStorage)
const save = () => {
  try {
    localStorage.setItem(K, JSON.stringify(db));
  } catch (e) {
    toast('⚠ Could not save data in this browser');
  }
};

// me = the logged-in user (null when logged out)
let me = null;

try {
  me = db.users.find((u) => u.id == localStorage.getItem('fc_me')) || null;
} catch (e) {}

// ui = what is on screen now: tab, cart, chat, errors
let ui = {
  ai: false,
  nb: 0,
  ep: 0,
  chat: { customer: [], admin: [], delivery: [] },
  tab: '',
  q: '',
  cat: 'All',
  cart: {},
  cp: null,
  role: 'customer',
  mode: 'login',
  err: '',
};

if (me) ui.tab = { customer: 'shop', admin: 'dash', delivery: 'tasks' }[me.role];

// Small pop-up message
function toast(m) {
  const t = $('#toast');
  t.textContent = m;
  t.style.display = 'block';
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (t.style.display = 'none'), 2200);
}

// Switch to another tab
const go = (t) => {
  ui.tab = t;
  R();
};

// Find a product by id
const pid = (id) => db.products.find((p) => p.id == id);

// Find a user by id
const du = (id) => db.users.find((u) => u.id == id) || { name: '(removed)' };
